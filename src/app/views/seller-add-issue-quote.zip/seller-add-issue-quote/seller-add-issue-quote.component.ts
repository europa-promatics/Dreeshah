import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl} from '@angular/forms';
//import { Component, OnInit } from '@angular/core';
// import {FormGroup, FormControl} from '@angular/forms';
//import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { CustomerService } from '../../shared/customer.service'
import { ToastrService } from 'ngx-toastr';
import { DatePipe } from '@angular/common';

import { environment } from 'src/environments/environment';
import Swal from 'sweetalert2';
import { Gallery, GalleryItem, ImageItem, ThumbnailsPosition, ImageSize } from '@ngx-gallery/core';
import { map } from 'rxjs/operators';
declare var $;
import * as moment from 'moment';
import { ThemePalette } from '@angular/material/core';
import { Options, LabelType } from '@angular-slider/ngx-slider';
import { Moment } from 'moment';
import { Validators } from '@angular/forms';
declare var $;
@Component({
  selector: 'app-seller-add-issue-quote',
  templateUrl: './seller-add-issue-quote.component.html',
  styleUrls: ['./seller-add-issue-quote.component.scss']
})
export class SellerAddIssueQuoteComponent implements OnInit {
  selected: {start: Moment, end: Moment};

  
  favoriteSeason: string;
  seasons: string[] = ['One Time Payment', 'Two Installments', 'Three Installments'];
  campaignOne: FormGroup;
  campaignTwo: FormGroup;
  quotationNum: number;
  submit_book: boolean;
  quotationForm:FormGroup;
  _id: any;
  professionalData: any;
  constructor(public gallery: Gallery,  private route: ActivatedRoute,
    private router: Router,
   // public _formBuilder: FormBuilder,
    public CustomerService: CustomerService,
    private toastr: ToastrService,) { 
  	const today = new Date();
    const month = today.getMonth();
    const year = today.getFullYear();
    

    this.campaignOne = new FormGroup({
      start: new FormControl(new Date(year, month, 13)),
      end: new FormControl(new Date(year, month, 16))
    });

    this.campaignTwo = new FormGroup({
      start: new FormControl(new Date(year, month, 15)),
      end: new FormControl(new Date(year, month, 19))
    });
  }
  ckeditorContent
  ngOnInit(): void {

    this.quotationForm = new FormGroup({
      title: new FormControl('', [Validators.required,]),
      warrenty: new FormControl('', [Validators.required,]),
      offer_validity: new FormControl('', [Validators.required,]),
      price: new FormControl('', [Validators.required,]),
      quantity: new FormControl('', [Validators.required,]),
      vat: new FormControl('', [Validators.required,]),
      scope_of_work: new FormControl('', [Validators.required,]),
      exclusion: new FormControl('', [Validators.required,]),
      add_terms_and_conditions_of_dreeshah: new FormControl('', [Validators.required,]),
      add_terms_and_conditions_of_seller: new FormControl('', [Validators.required,]),
      payment_terms: new FormControl('', [Validators.required,]),
      payment_percentage: new FormControl('', [Validators.required,]),
      start_date: new FormControl('', [Validators.required,]),
      end_date: new FormControl('', [Validators.required,]),
      work_schedule_start: new FormControl('', [Validators.required,]),
      date_range: new FormControl('', [Validators.required,]),
      work_schedule_end: new FormControl('', [Validators.required,]),})
 

    //   $(document).ready(function(){
    //     var counter = 0;
    //     $('.pls-icn').click(function(){
    //         $('.parent-module').add('.quote-main-module');
    //         $('.minus-icn').click(function(){
    //         $(this).closest('.rmve').remove();
    //         });
    //     });
    // });
    
    // another function starts here
//     $(document).ready(function() {
//   var max_fields      = 10; //maximum input boxes allowed
//   var wrapper       = $(".parent-module"); //Fields wrapper
//   var add_button      = $(".pls-icn"); //Add button ID
  
//   var x = 1; //initlal text box count
//   $(add_button).click(function(e){ //on add input button click
//     e.preventDefault();
//     if(x < max_fields){ //max input box allowed
//       x++; //text box increment
//       $(wrapper).append('<div class="quote-main-module mt-3"> <div class="form-group"> <div class="module-1"><h3>Module</h3><p>Lorem Ipsum </p></div><mat-form-field class="example-form-field" > <mat-date-range-input[formGroup]="campaignOne"[rangePicker]="campaignOnePicker"[comparisonStart]=""[comparisonEnd]=""><input matStartDate placeholder="Start date" formControlName="start"><input matEndDate placeholder="End date" formControlName="end"></mat-date-range-input><mat-datepicker-toggle matSuffix [for]="campaignOnePicker"></mat-datepicker-toggle> <mat-date-range-picker #campaignOnePicker></mat-date-range-picker></div></div>'); //add input box
//     }
//   });
  
//   $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
//     e.preventDefault(); $(this).parent('div').remove(); x--;
//   })
// });
  }
  submitQutation() {

    this.quotationNum = moment().unix()
    console.log("Quotation Number is>>>>", this.quotationNum)
    // console.log("Phone Number is>>>>", this.phone)
    // this.len2 = this.phone.length
    // console.log("Country Code is >>>>", this.countryDial)
    // console.log("Country Code Length is >>>>", this.countryDial.length)
    // this.len = this.countryDial.length

    // this.splitNum = this.phone.slice(this.len, this.len2)

    // this.timeQuo = moment(this.quotationForm.value.time).format('LT');
    // this.dateQuo = moment(this.quotationForm.value.date).format('LL');
    // this.dateQuo2 = moment(this.quotationForm.value.expected_date).format('LL');

    // console.log("Split Number is.>>>", this.splitNum)
    //  console.log("local====",localStorage['PROFESSIONAL_DATA'])
    // if (localStorage['PROFESSIONAL_DATA']) {
    //   this.professionalData = JSON.parse(localStorage['PROFESSIONAL_DATA']);
    //   console.log("user======>", this.professionalData)
    //   if (this.professionalData.user_type != "professional") {
    //     this.toastr.error("Please login as customer to continue")
    //     return
    //   } else {
        this.submit_book = true
        console.log("=====quatation form", this.quotationForm)
        var obj = {
          customer_id:this._id,
          title:'MY TITLE',
          warrenty:null,
          offer_validity:null,
          price:500,
          quantity:10,
          vat:10,
          workflow:[{
          title: "TITLENAME",
          data:[
          {
              "srNo" : 1,"itemName" : "furnishing","description" : "kjbkbk","price" :                                                 6767,"total_Price" : 8989
          },
          {
              "srNo" : 1,"itemName" : "furnishing","description" : "kjbkbk","price" :                                                 6767,"total_Price" : 8989
          },
            ]
          }
          ],
          scope_of_work:'any',
          exclusion:null,
          payment_terms:null,
          work_schedule:[{"module":"gfdh","description":"nothing","start_date":"2021-02-17T04:46:00.776Z","end_date":"2021-02-17T04:46:00.776Z"}],
          image: null
          
        }
        console.log("object of Instant Quotation ===>", obj)
        // this.phoneForm.controls.phone.patchValue(' ');
        // this.phoneForm.reset()
       // this.quotationForm.reset()

        $('#QuotationForm').modal('hide');
        // return
        this.CustomerService.AddQuotation(obj).subscribe(data => {
          console.log("Quotation Submit Response ====>>>>>>", data)
          // this.phoneForm.controls.phone.setValue('');
          // this.phoneForm.reset()
         // this.quotationForm.reset()

          $('#QuotationForm').modal('hide');
          this.toastr.success('Quotation Form submitted successfully', 'success')
        }, err => {
          console.log(err.status)
          if (err.status >= 404) {
            console.log('Some error occured')
          } else {
            this.toastr.error('Some error occured, please try again!!', 'Error')
            console.log('Internet Connection Error')
          }
        })
      
  //   } else {
  //     this.toastr.error("Please login as customer to continue")
  //     return
  //   }
  // }

}

}



