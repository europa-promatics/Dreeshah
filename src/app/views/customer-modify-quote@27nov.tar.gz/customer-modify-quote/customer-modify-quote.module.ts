import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerModifyQuoteRoutingModule } from './customer-modify-quote-routing.module';
//import { CKEditorModule } from 'ng2-ckeditor';
import { FormsModule } from '@angular/forms';
@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CustomerModifyQuoteRoutingModule,
   // CKEditorModule,
    FormsModule
  ]
})
export class CustomerModifyQuoteModule { }
